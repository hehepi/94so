# -*- coding: UTF-8 -*-
from config import Config
from app import app
from app.view import routing
from flask import session

app = app()
app.secret_key = 'wxcjq'


@app.route('/', methods=['GET', 'POST'])
def index():
    sess = session.get('token')
    if not sess:
        return routing.路由("login")
    else:
        return routing.路由("/")


@app.route('/<route_name>', methods=['GET', 'POST'])
def route(route_name):

    return routing.路由(route_name)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=Config.访问端口)
